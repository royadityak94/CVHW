import numpy as np
import cv2
import time

# This code is part of:
#
#   CMPSCI 670: Computer Vision, Fall 2019
#   University of Massachusetts, Amherst
#   Instructor: Subhransu Maji
#
#   Mini-project 4

def ransac(matches, blobs1, blobs2):
    # implement this
    pass


