function m = computeMatches(f1,f2)
% COMPUTEMATCHES Match two sets of SIFT features f1 and f2
% This code is part of:
%
%   CMPSCI 670: Computer Vision, Fall 2019
%   University of Massachusetts, Amherst
%   Instructor: Subhransu Maji
%
%   Mini project 4

% Implement this